/*
 * dshir003_lab2_part2.c
 *
 * Created: 4/4/2019 11:38:11 AM
 * Author : dspha
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

