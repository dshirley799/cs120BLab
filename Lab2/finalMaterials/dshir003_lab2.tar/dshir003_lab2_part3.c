/*
 * dshir003_lab2_part3.c
 *
 * Created: 4/4/2019 11:47:29 AM
 * Author : dspha
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

